import React from "react";
import { Link, useParams, Navigate } from "react-router-dom";
import { C, GRAD, SectionTitle, SmartImage, PageHero } from "../ui.jsx";
import { REGIONI, PAESI } from "../data/regioni.js";

/* ============================================================
   /regioni — Indice mondiale dei paesi
   ============================================================ */
export function RegioniIndex() {
  return (
    <>
      <PageHero
        eyebrow="Regioni del vino"
        title="Il mondo del vino, paese per paese"
        sub="Un atlante in costruzione: si parte dall'Italia, con nuove destinazioni in arrivo. Presto anche una mappa interattiva per esplorarle tutte."
      />
      <section style={{ padding: "clamp(50px, 7vw, 90px) clamp(20px, 5vw, 64px)", background: C.crema }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 24 }}>
            {PAESI.map((p) =>
              p.attivo ? (
                <Link
                  to={`/regioni/${p.slug}`}
                  key={p.slug}
                  style={{
                    background: "#fff",
                    borderRadius: 6,
                    padding: "30px 28px",
                    border: `2px solid ${C.verde}`,
                    transition: "box-shadow .2s",
                  }}
                >
                  <h2 style={{ fontFamily: "'Fraunces', serif", fontWeight: 500, fontSize: 30, margin: "0 0 6px", color: C.carbone }}>
                    {p.nome}
                  </h2>
                  <p style={{ fontSize: 14, fontWeight: 300, margin: "0 0 16px", color: C.ink }}>{p.descr}</p>
                  <span
                    style={{
                      fontSize: 13,
                      letterSpacing: "0.1em",
                      textTransform: "uppercase",
                      fontWeight: 700,
                      background: GRAD,
                      WebkitBackgroundClip: "text",
                      WebkitTextFillColor: "transparent",
                    }}
                  >
                    Esplora →
                  </span>
                </Link>
              ) : (
                <div
                  key={p.slug}
                  style={{
                    background: "#fff",
                    borderRadius: 6,
                    padding: "30px 28px",
                    opacity: 0.65,
                    border: `1px dashed ${C.grigio}`,
                  }}
                >
                  <h2 style={{ fontFamily: "'Fraunces', serif", fontWeight: 500, fontSize: 30, margin: "0 0 6px", color: C.carbone }}>
                    {p.nome}
                  </h2>
                  <p style={{ fontSize: 14, fontWeight: 300, margin: "0 0 16px", color: C.ink }}>{p.descr}</p>
                  <span style={{ fontSize: 12, letterSpacing: "0.16em", textTransform: "uppercase", fontWeight: 700, color: C.grigio }}>
                    In arrivo
                  </span>
                </div>
              )
            )}
          </div>
        </div>
      </section>
    </>
  );
}

/* ============================================================
   /regioni/italia — Pagina paese
   ============================================================ */
export function PaeseItalia() {
  return (
    <>
      <PageHero
        eyebrow="Italia"
        title="Le regioni del vino italiane"
        sub="Dal Nebbiolo delle Langhe ai Nerello dell'Etna: sei territori online, e la lista è destinata a crescere."
        img="langhe"
      />
      <section style={{ padding: "clamp(50px, 7vw, 90px) clamp(20px, 5vw, 64px)", background: C.crema }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 24 }}>
            {REGIONI.map((r) => (
              <Link to={`/regioni/italia/${r.slug}`} key={r.slug} className="region-card" style={{ height: 360 }}>
                <div className="region-img" style={{ position: "absolute", inset: 0 }}>
                  <SmartImage img={r.img} alt={r.nome} />
                </div>
                <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(29,33,28,0) 25%, rgba(29,33,28,0.94) 100%)" }} />
                <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: 24, color: C.crema }}>
                  <h2 style={{ fontFamily: "'Fraunces', serif", fontWeight: 500, fontSize: 28, margin: "0 0 2px" }}>{r.nome}</h2>
                  <div style={{ fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: C.lime, fontWeight: 700, marginBottom: 10 }}>
                    {r.zona}
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 12, opacity: 0.95 }}>{r.vitigni.slice(0, 3).join(" · ")}</div>
                  <span style={{ fontSize: 12, letterSpacing: "0.14em", textTransform: "uppercase", fontWeight: 700, color: C.lime }}>
                    Territorio, tour e cantine →
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

/* ============================================================
   /regioni/italia/:slug — Dettaglio regione
   ============================================================ */
export function RegioneDetail() {
  const { slug } = useParams();
  const r = REGIONI.find((x) => x.slug === slug);
  if (!r) return <Navigate to="/regioni/italia" replace />;

  return (
    <>
      <PageHero eyebrow={`Italia · ${r.zona}`} title={r.nome} sub={r.intro[0]} img={r.img} />

      {/* Territorio */}
      <section style={{ padding: "clamp(50px, 7vw, 80px) clamp(20px, 5vw, 64px)", background: C.crema }}>
        <div style={{ maxWidth: 860, margin: "0 auto" }}>
          <SectionTitle eyebrow="Il territorio" title={`Perché ${r.nome}`} />
          {r.intro.map((p, i) => (
            <p key={i} style={{ fontSize: 17, lineHeight: 1.75, fontWeight: 300, margin: "0 0 20px", color: C.ink }}>
              {p}
            </p>
          ))}
          <div style={{ marginTop: 28 }}>
            <div style={{ fontSize: 12, letterSpacing: "0.2em", textTransform: "uppercase", fontWeight: 700, color: C.verde, marginBottom: 12 }}>
              Vitigni principali
            </div>
            <div>{r.vitigni.map((v) => <span className="chip" key={v}>{v}</span>)}</div>
            <div style={{ fontSize: 12, letterSpacing: "0.2em", textTransform: "uppercase", fontWeight: 700, color: C.verde, margin: "20px 0 12px" }}>
              Denominazioni
            </div>
            <div>{r.denominazioni.map((d) => <span className="chip" key={d}>{d}</span>)}</div>
          </div>
        </div>
      </section>

      {/* Tour */}
      <section id="tour" style={{ background: C.carbone, color: C.crema, padding: "clamp(50px, 7vw, 80px) clamp(20px, 5vw, 64px)" }}>
        <div style={{ maxWidth: 860, margin: "0 auto" }}>
          <SectionTitle eyebrow={`Il tour · ${r.tour.durata}`} title={r.tour.titolo} light />
          <p style={{ fontSize: 17, lineHeight: 1.7, fontWeight: 300, opacity: 0.92, margin: "0 0 28px" }}>
            {r.tour.descrizione}
          </p>
          <div style={{ display: "grid", gap: 14 }}>
            {r.tour.tappe.map((t, i) => (
              <div key={i} style={{ display: "flex", gap: 16, alignItems: "baseline" }}>
                <span
                  style={{
                    fontFamily: "'Fraunces', serif",
                    fontSize: 20,
                    minWidth: 28,
                    background: GRAD,
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                  }}
                >
                  {String(i + 1).padStart(2, "0")}
                </span>
                <p style={{ fontSize: 15, lineHeight: 1.6, fontWeight: 300, margin: 0, opacity: 0.92 }}>{t}</p>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 36 }}>
            <a href="mailto:info@winexciting.com?subject=Richiesta informazioni tour" className="btn-lime">
              Richiedi informazioni
            </a>
          </div>
        </div>
      </section>

      {/* Cantine */}
      <section style={{ padding: "clamp(50px, 7vw, 80px) clamp(20px, 5vw, 64px)", background: C.crema }}>
        <div style={{ maxWidth: 860, margin: "0 auto" }}>
          <SectionTitle eyebrow="Da visitare" title={`Le cantine: ${r.nome}`} />
          <div style={{ display: "grid", gap: 14 }}>
            {r.cantine.map((c) => (
              <div className="cantina-row" key={c.nome}>
                <div>
                  <h3 style={{ fontFamily: "'Fraunces', serif", fontWeight: 500, fontSize: 20, margin: "0 0 4px", color: C.carbone }}>
                    {c.nome}
                  </h3>
                  <div style={{ fontSize: 13, color: C.verde, fontWeight: 600, marginBottom: 4 }}>{c.comune}</div>
                  <p style={{ fontSize: 14, fontWeight: 300, margin: 0, color: C.ink }}>{c.visite}</p>
                </div>
                <a
                  href={`https://${c.sito}`}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-ghost dark"
                  style={{ padding: "10px 20px", fontSize: 12 }}
                >
                  Sito web
                </a>
              </div>
            ))}
          </div>
          <p style={{ fontSize: 13, fontWeight: 300, color: C.grigio, marginTop: 20 }}>
            Elenco in costruzione: la directory completa delle cantine della regione è in arrivo.
          </p>
        </div>
      </section>

      {/* Navigazione tra regioni */}
      <section style={{ padding: "0 clamp(20px, 5vw, 64px) clamp(50px, 7vw, 80px)", background: C.crema }}>
        <div style={{ maxWidth: 860, margin: "0 auto", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
          <Link to="/regioni/italia" className="btn-ghost dark">← Tutte le regioni italiane</Link>
          <Link to="/tour" className="btn-ghost dark">Tutti i tour →</Link>
        </div>
      </section>
    </>
  );
}

/* ============================================================
   /tour — Indice dei tour
   ============================================================ */
export function TourIndex() {
  return (
    <>
      <PageHero
        eyebrow="Tour enogastronomici"
        title="Esperienze tra le vigne"
        sub="Itinerari pensati per vivere ogni regione dal punto di vista giusto: quello del calice. Un tour per ogni territorio."
        img="chianti"
      />
      <section style={{ padding: "clamp(50px, 7vw, 90px) clamp(20px, 5vw, 64px)", background: C.crema }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(400px, 1fr))", gap: 28 }}>
            {REGIONI.map((r) => (
              <Link to={`/regioni/italia/${r.slug}#tour`} key={r.slug}>
                <article className="tour-card">
                  <div style={{ height: 210, overflow: "hidden" }}>
                    <SmartImage img={r.img} alt={r.tour.titolo} />
                  </div>
                  <div className="tour-body">
                    <div style={{ fontSize: 11, letterSpacing: "0.18em", textTransform: "uppercase", color: C.verde, marginBottom: 10, fontWeight: 700 }}>
                      {r.zona} · {r.tour.durata}
                    </div>
                    <h3 style={{ fontFamily: "'Fraunces', serif", fontWeight: 500, fontSize: 24, margin: "0 0 12px", color: C.carbone }}>
                      {r.tour.titolo}
                    </h3>
                    <p style={{ fontSize: 15, lineHeight: 1.6, fontWeight: 300, margin: "0 0 20px", color: C.ink }}>
                      {r.tour.descrizione}
                    </p>
                    <span
                      style={{
                        fontSize: 13,
                        letterSpacing: "0.1em",
                        textTransform: "uppercase",
                        fontWeight: 700,
                        background: GRAD,
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                        marginTop: "auto",
                      }}
                    >
                      Itinerario completo →
                    </span>
                  </div>
                </article>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
