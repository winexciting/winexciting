import React, { useState } from "react";
import { Link } from "react-router-dom";
import { C, GRAD, LogoSeal, SectionTitle, SmartImage } from "../ui.jsx";
import { REGIONI } from "../data/regioni.js";

const SITE = {
  sottoClaim:
    "Racconti, tour enogastronomici e video dalle regioni vitivinicole del mondo. Si parte dall'Italia.",
  instagram: "https://instagram.com/winexciting",
  youtube: "https://youtube.com/@winexciting",
};

/* I video restano qui finché non avranno una pagina dedicata */
const VIDEOS = [
  { id: 1, titolo: "Vendemmia all'alba nelle Langhe", regione: "Piemonte", youtubeId: "", cover: "langhe" },
  { id: 2, titolo: "Le terrazze dell'Etna", regione: "Sicilia", youtubeId: "", cover: "etna" },
];

export default function Home() {
  const tourInEvidenza = REGIONI.slice(0, 4);

  return (
    <>
      {/* ===== HERO ===== */}
      <section style={{ background: C.carbone, color: C.crema, position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, opacity: 0.28 }}>
          <SmartImage img="langhe" alt="Vigneti delle Langhe" />
        </div>
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: "linear-gradient(180deg, rgba(29,33,28,0.3) 0%, rgba(29,33,28,0.85) 85%)",
          }}
        />
        <div
          style={{
            maxWidth: 1100,
            margin: "0 auto",
            padding: "clamp(80px, 12vw, 150px) clamp(20px, 5vw, 64px) clamp(70px, 9vw, 110px)",
            position: "relative",
            zIndex: 1,
          }}
        >
          <h1
            style={{
              fontFamily: "'Fraunces', serif",
              fontWeight: 500,
              fontSize: "clamp(48px, 9vw, 104px)",
              lineHeight: 1.0,
              margin: 0,
            }}
          >
            Endless{" "}
            <span style={{ background: GRAD, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              Passion.
            </span>
          </h1>
          <p
            style={{
              fontSize: "clamp(16px, 2vw, 20px)",
              fontWeight: 300,
              lineHeight: 1.65,
              maxWidth: 540,
              margin: "26px 0 40px",
              opacity: 0.92,
            }}
          >
            {SITE.sottoClaim}
          </p>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            <Link to="/tour" className="btn-lime">Scopri i tour</Link>
            <Link to="/regioni" className="btn-ghost">Esplora le regioni</Link>
          </div>
        </div>
      </section>

      {/* ===== TOUR IN EVIDENZA ===== */}
      <section style={{ padding: "clamp(60px, 8vw, 100px) clamp(20px, 5vw, 64px)" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <SectionTitle eyebrow="Tour enogastronomici" title="Esperienze tra le vigne" />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(400px, 1fr))", gap: 28 }}>
            {tourInEvidenza.map((r) => (
              <Link to={`/regioni/italia/${r.slug}#tour`} key={r.slug}>
                <article className="tour-card">
                  <div style={{ height: 210, overflow: "hidden" }}>
                    <SmartImage img={r.img} alt={r.tour.titolo} style={{}} />
                  </div>
                  <div className="tour-body">
                    <div style={{ fontSize: 11, letterSpacing: "0.18em", textTransform: "uppercase", color: C.verde, marginBottom: 10, fontWeight: 700 }}>
                      {r.zona} · {r.tour.durata}
                    </div>
                    <h3 style={{ fontFamily: "'Fraunces', serif", fontWeight: 500, fontSize: 24, margin: "0 0 12px", color: C.carbone }}>
                      {r.tour.titolo}
                    </h3>
                    <p style={{ fontSize: 15, lineHeight: 1.6, fontWeight: 300, margin: "0 0 20px", color: C.ink }}>
                      {r.tour.descrizione}
                    </p>
                    <span
                      style={{
                        fontSize: 13,
                        letterSpacing: "0.1em",
                        textTransform: "uppercase",
                        fontWeight: 700,
                        background: GRAD,
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                        marginTop: "auto",
                      }}
                    >
                      Scopri di più →
                    </span>
                  </div>
                </article>
              </Link>
            ))}
          </div>
          <div style={{ textAlign: "center", marginTop: 40 }}>
            <Link to="/tour" className="btn-ghost dark">Tutti i tour</Link>
          </div>
        </div>
      </section>

      {/* ===== VIDEO ===== */}
      <section style={{ background: C.carbone, padding: "clamp(60px, 8vw, 100px) clamp(20px, 5vw, 64px)" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <SectionTitle eyebrow="Video delle vigne" title="Il racconto, dal filare al calice" light />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 28 }}>
            {VIDEOS.map((v) => (
              <div key={v.id}>
                {v.youtubeId ? (
                  <div style={{ position: "relative", paddingBottom: "56.25%", height: 0, borderRadius: 6, overflow: "hidden" }}>
                    <iframe
                      src={`https://www.youtube.com/embed/${v.youtubeId}`}
                      title={v.titolo}
                      style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", border: 0 }}
                      allowFullScreen
                    />
                  </div>
                ) : (
                  <div style={{ position: "relative", borderRadius: 6, overflow: "hidden", height: 240 }}>
                    <SmartImage img={v.cover} alt={v.titolo} style={{ filter: "brightness(0.65)" }} />
                    <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                      <div style={{ width: 66, height: 66, borderRadius: "50%", background: GRAD, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <div style={{ width: 0, height: 0, borderTop: "12px solid transparent", borderBottom: "12px solid transparent", borderLeft: `20px solid ${C.carbone}`, marginLeft: 5 }} />
                      </div>
                    </div>
                  </div>
                )}
                <div style={{ paddingTop: 14 }}>
                  <div style={{ fontSize: 11, letterSpacing: "0.18em", textTransform: "uppercase", color: C.lime, fontWeight: 700, marginBottom: 6 }}>
                    {v.regione}
                  </div>
                  <h3 style={{ fontFamily: "'Fraunces', serif", fontWeight: 500, fontSize: 20, margin: 0, color: C.crema }}>
                    {v.titolo}
                  </h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== REGIONI ===== */}
      <section style={{ padding: "clamp(60px, 8vw, 100px) clamp(20px, 5vw, 64px)" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <SectionTitle eyebrow="Regioni del vino" title="L'Italia, una regione alla volta" />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: 24 }}>
            {REGIONI.map((r) => (
              <Link to={`/regioni/italia/${r.slug}`} key={r.slug} className="region-card" style={{ height: 340 }}>
                <div className="region-img" style={{ position: "absolute", inset: 0 }}>
                  <SmartImage img={r.img} alt={r.nome} />
                </div>
                <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(29,33,28,0) 30%, rgba(29,33,28,0.92) 100%)" }} />
                <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: 22, color: C.crema }}>
                  <h3 style={{ fontFamily: "'Fraunces', serif", fontWeight: 500, fontSize: 26, margin: "0 0 2px" }}>{r.nome}</h3>
                  <div style={{ fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: C.lime, fontWeight: 700, marginBottom: 10 }}>
                    {r.zona}
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 6, opacity: 0.95 }}>{r.vitigni.slice(0, 3).join(" · ")}</div>
                  <p style={{ fontSize: 13, lineHeight: 1.5, fontWeight: 300, margin: 0, opacity: 0.85 }}>{r.intro[0].slice(0, 90)}…</p>
                </div>
              </Link>
            ))}
          </div>
          <div style={{ textAlign: "center", marginTop: 40 }}>
            <Link to="/regioni" className="btn-ghost dark">Tutte le regioni del mondo</Link>
          </div>
        </div>
      </section>

      {/* ===== IL PROGETTO ===== */}
      <section id="il-progetto" style={{ background: C.carbone, color: C.crema, padding: "clamp(60px, 8vw, 100px) clamp(20px, 5vw, 64px)" }}>
        <div style={{ maxWidth: 760, margin: "0 auto", textAlign: "center" }}>
          <div style={{ marginBottom: 24 }}>
            <LogoSeal size={140} />
          </div>
          <SectionTitle eyebrow="Il progetto" title="Diffondere la passione, un calice alla volta" light />
          <p style={{ fontSize: 17, lineHeight: 1.75, fontWeight: 300, opacity: 0.9, margin: "0 0 32px" }}>
            Winexciting nasce dalla passione per il vino e per le persone che lo fanno. Niente
            tecnicismi da sommelier, niente punteggi: solo territori, storie e bottiglie che vale la
            pena conoscere. Si parte dall'Italia, si guarda al mondo.
          </p>
          <a href={SITE.instagram} target="_blank" rel="noreferrer" className="btn-ghost">
            Seguici su Instagram
          </a>
        </div>
      </section>
    </>
  );
}
